document.addEventListener('DOMContentLoaded', () => {
      // 1. Header Scroll State
      const header = document.getElementById('header');
      window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
          header.classList.add('scrolled');
        } else {
          header.classList.remove('scrolled');
        }
      });

      // 2. Custom Cursor
      const cursorDot = document.getElementById('cursorDot');
      const cursorGlow = document.getElementById('cursorGlow');

      if (cursorDot && cursorGlow) {
        window.addEventListener('mousemove', (e) => {
          cursorDot.style.left = `${e.clientX}px`;
          cursorDot.style.top = `${e.clientY}px`;

          cursorGlow.style.left = `${e.clientX}px`;
          cursorGlow.style.top = `${e.clientY}px`;
        });

        const hoverables = document.querySelectorAll('a, button, .system-node, .skill-node, .principle-card');
        hoverables.forEach(el => {
          el.addEventListener('mouseenter', () => document.body.classList.add('cursor-hover'));
          el.addEventListener('mouseleave', () => document.body.classList.remove('cursor-hover'));
        });
      }

      // 3. Mobile Menu Navigation Toggle
      const mobileToggle = document.getElementById('mobileToggle');
      const mobileNav = document.getElementById('mobileNav');
      const mobileLinks = document.querySelectorAll('.mobile-link');

      if (mobileToggle && mobileNav) {
        mobileToggle.addEventListener('click', () => {
          mobileNav.classList.toggle('active');
        });

        mobileLinks.forEach(link => {
          link.addEventListener('click', () => {
            mobileNav.classList.remove('active');
          });
        });
      }

      // 4. Hero Heading Text Carousel Auto-Rotation
      const slides = document.querySelectorAll('.hero-carousel .carousel-slide');
      let currentSlide = 0;

      if (slides.length > 0) {
        setInterval(() => {
          slides[currentSlide].classList.remove('active');
          currentSlide = (currentSlide + 1) % slides.length;
          slides[currentSlide].classList.add('active');
        }, 4000);
      }

      // 5. Contact Form Validation
      const contactForm = document.getElementById('contactForm');
      const formStatus = document.getElementById('formStatus');

      if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
          e.preventDefault();

          const nameInput = document.getElementById('name');
          const emailInput = document.getElementById('email');
          const messageInput = document.getElementById('message');

          const nameError = document.getElementById('nameError');
          const emailError = document.getElementById('emailError');
          const messageError = document.getElementById('messageError');

          let isValid = true;

          if (!nameInput.value.trim()) {
            nameError.style.display = 'block';
            isValid = false;
          } else {
            nameError.style.display = 'none';
          }

          const emailPattern = /^[^s@]+@[^s@]+.[^s@]+$/;
          if (!emailPattern.test(emailInput.value.trim())) {
            emailError.style.display = 'block';
            isValid = false;
          } else {
            emailError.style.display = 'none';
          }

          if (!messageInput.value.trim()) {
            messageError.style.display = 'block';
            isValid = false;
          } else {
            messageError.style.display = 'none';
          }

          if (isValid) {
            formStatus.style.color = '#00FF66';
            formStatus.textContent = 'Thank you! Your message has been sent successfully.';
            contactForm.reset();
          }
        });
      }
    });
