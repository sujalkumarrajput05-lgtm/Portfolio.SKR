SUJAL K.R. PORTFOLIO
====================

Folder structure:
- index.html          Main HTML structure/content
- css/style.css       All CSS/design/animations/responsive styles
- js/main.js          Header scroll, custom cursor, mobile menu, hero carousel,
                      and contact-form validation
- assets/             Put images such as og-image.jpg and other portfolio assets here

Run:
1. Keep the folder structure unchanged.
2. Open index.html in a browser, or deploy the whole folder to your hosting.

The original single-file HTML was split without changing the portfolio content.
